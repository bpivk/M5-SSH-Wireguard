// ESP32 libssh port.
// libssh_esp32_info.h
//
// Ewan Parker, created 6th April 2025.
// Arduino library header needed to report version information for libssh
// to ESP32.
//
// Copyright (C) 2020–2026 Ewan Parker.

#pragma once

#define LIBSSH_ESP32_VERSION_MAJOR 5
#define LIBSSH_ESP32_VERSION_MINOR 8
#define LIBSSH_ESP32_VERSION_PATCH 0
